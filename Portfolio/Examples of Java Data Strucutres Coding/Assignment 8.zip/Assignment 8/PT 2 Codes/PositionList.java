public interface PositionList<E>
{
	/**return number of elements in list*/
	public int size();
	/**return true if list size is zero, and false otherwise*/
	public boolean isEmpty();
	/** returns first position in list, after header*/
	public Position<E> first();
	/** returns last position in list, before trailer */
	public Position<E> last();
	/** returns previous position in list */
	public Position<E> prev(Position<E> p)
		throws InvalidPositionException;
	/** returns next position in list */
	public Position<E> after(Position<E> p)
		throws InvalidPositionException;
	/** create a new node infront of position p */
	public void addBefore(Position<E> p, E e)
		throws InvalidPositionException;
	/** create a new node behind of position p */
	public void addAfter(Position<E> p, E e)
		throws InvalidPositionException;
	/** create new node at beginning of list*/
	public void addFirst(E e);
	/** create new node at end of list*/
	public void addLast(E e);
	/** remove the node at position p */
	public E remove(Position<E> p)
		throws InvalidPositionException;
	/** change the value of the element stored in node at position p */
	public E replace(Position<E> p, E e)
		throws InvalidPositionException;
}