import java.util.*;
import java.lang.Iterable;

public class NodePositionList<E> implements PositionList<E>, Iterable<E>
{
	protected DNode<E> header;
	protected DNode<E> trailer;
	protected int size;

	/** no-arg constructor */
	public NodePositionList()
	{
		//create header node
		header = new DNode<E>(null, null, null);
		//create trailer node, prev points to header
		trailer = new DNode<E>(header, null, null);
		//header points to trailer
		header.setNext(trailer);
		//zero elements in list
		size = 0;
	}

	/**return number of elements in list*/
	public int size()
	{
		return size;
	}

	/**return true if list size is zero*/
	public boolean isEmpty()
	{
		if(size > 0)
			return false;
		else
			return true;
	}

	/** checks if given position is valid, then casts and returns as DNode */
	public DNode<E> checkPosition(Position<E> p) throws InvalidPositionException
	{
		//invalid if position is null or equal to header or trailer
		if(p == null)
			throw new InvalidPositionException("Position is null.");
		if(p == header)
			throw new InvalidPositionException("header is not a position.");
		if(p == trailer)
			throw new InvalidPositionException("gtrialer is not a position");

		DNode<E> temp = null;

		//attempt to cast position to node
		try
		{
			temp = (DNode<E>) p;
		}
		catch(ClassCastException e)
		{
			throw new InvalidPositionException("class cast exception.");
		}
		//check that position p is part of a list and cast to DNode
		if(temp.getPrev() == null || temp.getNext() == null)
				throw new InvalidPositionException("Position is not linked to two other positions");
			return temp;
	}

	/** returns first position in list, after header */
	public Position<E> first()
	{
		return header.getNext();
	}

	/** returns last position in list, before trailer */
	public Position<E> last()
	{
		return trailer.getPrev();
	}

	/** returns previous position in list */
	public Position<E> prev(Position<E> p) throws InvalidPositionException
	{
		DNode<E> node = checkPosition(p);
		return node.getPrev();
	}

	/** returns next position in list */
	public Position<E> after(Position<E> p) throws InvalidPositionException
	{
		DNode<E> node = checkPosition(p);
		return node.getNext();
	}

	/** create a new node infront of position p */
	public void addBefore(Position<E> p, E e) throws InvalidPositionException
	{
		DNode<E> nodeAfter = checkPosition(p);
		DNode<E> nodeBefore = nodeAfter.getPrev();
		//create new node that points to nodeBefore and nodeAfter
		DNode<E> newNode = new DNode<E>(nodeBefore, nodeAfter, e);
		//Before and after nodes point to new node
		nodeBefore.setNext(newNode);
		nodeAfter.setPrev(newNode);
		//update size
		size++;
	}

	/** create a new node behind of position p */
	public void addAfter(Position<E> p, E e) throws InvalidPositionException
	{
		DNode<E> nodeBefore = checkPosition(p);
		DNode<E> nodeAfter = nodeBefore.getNext();
		//create new node that points to nodeBefore and nodeAfter
		DNode<E> newNode = new DNode<E>(nodeBefore, nodeAfter, e);
		//Before and after nodes point to new node
		nodeBefore.setNext(newNode);
		nodeAfter.setPrev(newNode);
		//update size
		size++;
	}

	/** create new node at beginning of list*/
	public void addFirst(E e)
	{
		DNode<E> nodeAfter = header.getNext();
		//new node points to nodeAfter and header
		DNode<E> newNode = new DNode<E>(header, nodeAfter, e);
		//point node after header to new node
		nodeAfter.setPrev(newNode);
		//header points to new node
		header.setNext(newNode);
		size++;
	}

	/** create new node at end of list*/
	public void addLast(E e)
	{
		DNode<E> nodeBefore = trailer.getPrev();
		//new node points to nodeBefore and trailer
		DNode<E> newNode = new DNode<E>(nodeBefore, trailer, e);
		//point node after header to new node
		nodeBefore.setNext(newNode);
		//header points to new node
		trailer.setPrev(newNode);
		size++;
	}

	/** remove the node at position p */
	public E remove(Position<E> p) throws InvalidPositionException
	{
		//checks position and casts to DNode
		DNode<E> node = checkPosition(p);
		//variable to hold element at p
		E temp = p.getElement();
		//declare nodes on either side of node to be removed
		DNode<E> nodeBefore = node.getPrev();
		DNode<E> nodeAfter = node.getNext();
		//nodes on either side point to each other
		//node is garbage collected, so its pointers are left unchanged
		nodeBefore.setNext(nodeAfter);
		nodeAfter.setPrev(nodeBefore);
		//decriment size
		size--;

		return temp;
	}

	/** change the value of the element stored in node at position p */
	public E replace(Position<E> p, E e) throws InvalidPositionException
	{
		//checks position and casts to DNode
		DNode<E> node = checkPosition(p);
		//variable to hold element at p
		E temp = p.getElement();
		//set elemnt to new value
		node.setElement(e);
		//return original value
		return temp;
	}

	public Iterator<E> iterator()
	{
		return new ElementIterator(this);
	}

	private class ElementIterator<E> implements Iterator<E>
	{
		protected NodePositionList<E> list;
		private Position<E> cursor;
		private Position<E> recent = null;

		public ElementIterator(NodePositionList<E> list)
		{
			this.list = list;
			cursor = list.first();
		}

		public boolean hasNext()
		{
			try
			{
				list.checkPosition(cursor);
			}
			catch(InvalidPositionException e)
			{
				return false;
			}
			return true;
		}

		public E next() throws NoSuchElementException
		{
			if(cursor == null)
				throw new NoSuchElementException("null position");
			recent = cursor;
			try
			{
				cursor = list.after(cursor);
			}
			catch(InvalidPositionException e)
			{
				throw new NoSuchElementException("InvalidPositionException: break in iterator");
			}
			return recent.getElement();
		}
	}

	public String toString()
	{
		String str = "";
		Iterator<E> iter = iterator();
		while(iter.hasNext())
		{
			str = str + iter.next() + ", ";
		}
		return str;
	}
}