 import java.util.*;


public class UnsortedPriorityQueue<K,V>
{
	private NodePositionList<Entry<K,V>> list;
	private Comparator<K>  comp;

	public UnsortedPriorityQueue()
	{
		list = new NodePositionList();
		comp = new DefaultComparator<K>();
	}

	public UnsortedPriorityQueue(Comparator<K> c)
	{
		list = new NodePositionList();
		comp = c;
	}

	public int size()
	{
		return list.size();
	}

	public boolean isEmpty()
	{
		return list.isEmpty();
	}

	protected static class PQEntry<K,V> implements Entry<K,V>
	{
		private K key;
		private V value;

		public PQEntry(K k, V v)
		{
			key = k;
			value = v;
		}

		public K getKey()
		{
			return key;
		}

		public V getValue()
		{
			return value;
		}

		public String toString()
		{
			return "(" + key + ", " + value + ")";
		}
	}

	public Entry<K,V> min() throws EmptyPriorityQueueException, InvalidPositionException
	{
		if(list.isEmpty())
			throw new EmptyPriorityQueueException("Empty");
		return minPosition().getElement();
	}

	public Entry<K,V> insert(K k, V v) throws IllegalArgumentException
	{
		checkKey(k);
		Entry<K,V> entry = new PQEntry<K,V>(k,v);
		list.addFirst(entry);
		return entry;
	}

	public Entry<K,V> removeMin() throws EmptyPriorityQueueException, InvalidPositionException
	{
		if(list.isEmpty())
			return null;
		return list.remove(minPosition());
	}

	//auxillary methods
	protected Position<Entry<K,V>> minPosition() throws EmptyPriorityQueueException, InvalidPositionException
	{
		if(list.isEmpty())
			throw new EmptyPriorityQueueException("ahhhh");
		else
		{
			Position<Entry<K,V>> current = list.after(list.first());
			Position<Entry<K,V>> min = list.first();

			while(current.getElement() != null)
			{
				if(comp.compare(min.getElement().getKey(), current.getElement().getKey()) > 0)
				{
					min = current;
					current = list.after(current);
				}
				else
				{
					current = list.after(current);
				}
			}
			return min;
		}
	}


	public boolean checkKey(K key) throws IllegalArgumentException
	{
		try
		{
			return comp.compare(key,key) == 0;
		}
		catch(ClassCastException e)
		{
			throw new IllegalArgumentException("no");
		}
	}

	public String toString(){
		return list.toString();
	}

	public static void main(String[] args)
	{
		UnsortedPriorityQueue<Integer, Integer> intq = new UnsortedPriorityQueue<Integer, Integer>();

		for (int i = 1; i <= 10; i++)
		{
			int j = (int)(Math.random()*50) + 1;
			intq.insert(j, j);
		}

		for (int i = 0; i < 10; i++){
			System.out.println(intq.removeMin());
		}

		System.out.println();
		System.out.println();
		System.out.println("Now for the sorting by the Binary Tester.");

		UnsortedPriorityQueue<Integer, Integer> binaryQ = new UnsortedPriorityQueue<Integer, Integer>(new BinaryTest());

		for (int i = 1; i <= 10; i++)
		{
			int j = (int)(Math.random() * 50) + 1;
			binaryQ.insert(j, j);
		}

		for (int i = 0; i < 10; i++)
		{
			System.out.println(binaryQ.removeMin());
		}
	}
}