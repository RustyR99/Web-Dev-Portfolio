import java.util.*;

public class BinaryTest<E> implements Comparator<E>
{
	public int compare(E a, E b)
	{
		int valA = countBits2(a);
		int valB = countBits2(b);
		return (valA - valB);
	}

	private int countBits2(E a)
	{
		if (a == null)
			throw new RuntimeException("null arguement");
		try
		{
			int numOnes = 0;
			String str = Integer.toBinaryString((Integer) a);
			for(int i = 0; i < str.length(); i++)
			{
				if(str.charAt(i)=='1')
					numOnes++;
			}
			return numOnes;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return 0;
	}
}