public class DNode<E> implements Position<E>
{
	protected E element;
	protected DNode<E> next, prev;

	/** Constructor */
	public DNode(DNode<E> p, DNode<E> n, E e )
	{
		element = e;
		prev = p;
		next = n;
	}

	public E getElement()
	{
		return element;
	}

	public DNode<E> getNext()
	{
		return next;
	}

	public DNode<E> getPrev()
	{
		return prev;
	}

	public void setNext(DNode<E> n)
	{
		next = n;
	}

	public void setPrev(DNode<E> p)
	{
		prev = p;
	}

	public void setElement(E e)
	{
		element = e;
	}
}