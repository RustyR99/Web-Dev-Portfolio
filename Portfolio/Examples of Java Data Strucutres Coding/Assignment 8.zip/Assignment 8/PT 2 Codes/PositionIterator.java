import java.util.*;

public class PositionIterator<E> implements Iterator<Position<E>>
{
	protected NodePositionList<E> list;
	private Position<E> cursor;
	private Position<E> recent = null;

	public PositionIterator(NodePositionList<E> list)
	{
		this.list = list;
		cursor = list.first();
	}

	public boolean hasNext()
	{
		try
		{
			list.checkPosition(cursor);
		}
		catch(InvalidPositionException e)
		{
			return false;
		}
		return true;
		
	}

	public Position<E> next() throws NoSuchElementException
	{
		if(cursor == null)
			throw new NoSuchElementException("null position");
		recent = cursor;
		try
		{
			cursor = list.after(cursor);
		}
		catch(InvalidPositionException e)
		{
			throw new NoSuchElementException("InvalidPositionException: break in iterator");	
		}
		return recent;
	}
}