import java.util.*;
import java.lang.*;

public class LinkedBinaryTree<E> implements BinaryTree<E>
{
	//fields
	BTNode<E> root;
	int size;


	public LinkedBinaryTree()
	{
		root = null;
		size = 0;
	}

	//this will cast my position to a node
	public BTNode<E> checkPosition(Position<E> pos) throws InvalidPositionException
	{
		if(pos == null || !(pos instanceof BTNode))
			throw new InvalidPositionException("Invalid Position");
		return (BTNode<E>) pos;
	}

	public int size()
	{
		return size;
	}

	public boolean isEmpty()
	{
		return size() == 0;
	}
	//returns sthe root of my tree
	public Position<E> root() throws EmptyTreeException
	{
		if(isEmpty())
			throw new EmptyTreeException("the tree is empty");
		return root;
	}
//returns the parent of a given pos
	public Position<E> parent(Position<E> pos) throws InvalidPositionException
	{
		BTNode<E> node = checkPosition(pos);
		if(isRoot(node))
			throw new InvalidPositionException("the root has no parenst");
		return node.getParent();
	}
//returns if the pos has a left child and returns said child
	public Position<E> left(Position<E> pos)throws InvalidPositionException, BoundaryViolationException
	{
		BTNode<E> node = checkPosition(pos);

		if(!hasLeft(node))
			throw new BoundaryViolationException("no left child");
		return node.getLeft();
	}
//ref above method
	public Position<E> right(Position<E> pos)throws InvalidPositionException, BoundaryViolationException
	{
		BTNode<E> node = checkPosition(pos);

		if(!hasRight(node))
			throw new BoundaryViolationException("no right child");
		return node.getRight();
	}
//returns true if the pos has a left child
	public boolean hasLeft(Position<E> pos) throws InvalidPositionException
	{
		BTNode<E> node = checkPosition(pos);
		return (node.getLeft() != null);
	}
//ditto above
	public boolean hasRight(Position<E> pos) throws InvalidPositionException
	{
		BTNode<E> node = checkPosition(pos);
		return (node.getRight() != null);
	}
//returns true if the pos is internal
	public boolean isInternal(Position<E> pos) throws InvalidPositionException
	{
		BTNode<E> node = checkPosition(pos);
		return (hasLeft(node) || hasRight(node));
	}
//returns true if the pos is external
	public boolean isExternal(Position<E> pos)throws InvalidPositionException
	{
		return !isInternal(pos);
	}
//returns if the given pos is a root
	public boolean isRoot(Position<E> pos) throws InvalidPositionException
	{
		BTNode<E> node = checkPosition(pos);
		return node == root;
	}
//returns itearble of the children of a given pos
	public Iterable<Position<E>> children(Position<E> pos) throws InvalidPositionException, BoundaryViolationException
	{
		ArrayList<Position<E>> children = new ArrayList<>(2);
		if(hasLeft(pos))
			children.add(left(pos));
		if(hasRight(pos))
			children.add(right(pos));
		return children;
	}

	public Iterable<Position<E>> positions() throws InvalidPositionException, EmptyTreeException, BoundaryViolationException
	{
		return preOrder();
	}

	//iterable list of elts
	public Iterable<E> iterator() throws InvalidPositionException, EmptyTreeException, BoundaryViolationException
	{
		ArrayList<E> elts = new ArrayList<>();
		for(Position<E> pos : positions())
		{
			elts.add(pos.getElement());
		}
		return elts;
	}

	protected Iterable<Position<E>> preOrder() throws InvalidPositionException, EmptyTreeException, BoundaryViolationException
	{
		ArrayList<Position<E>> ar = new ArrayList<>();
		if(!isEmpty())
		{
			preOrderSubTree(root(), ar);
		}

		return ar;
	}

	protected void preOrderSubTree(Position<E> subRoot, ArrayList<Position<E>> ar) throws InvalidPositionException, BoundaryViolationException
	{
		ar.add(subRoot);
		for(Position<E> pos : children(subRoot))
		{
			preOrderSubTree(pos, ar);
		}
	}
//returns an iterable array of pos in order
	protected Iterable<Position<E>> inOrder() throws InvalidPositionException, EmptyTreeException, BoundaryViolationException
	{
		ArrayList<Position<E>> ar = new ArrayList<>();
		if(!isEmpty())
		{
			inOrderSubTree(root(), ar);
		}

		return ar;
	}
//aux method for inOrder taken from textbook
	protected void inOrderSubTree(Position<E> pos, ArrayList<Position<E>> ar) throws InvalidPositionException, BoundaryViolationException
	{
		BTNode<E> node = checkPosition(pos);
		if(node.getLeft() != null)
			inOrderSubTree(node.getLeft(), ar);
		ar.add(pos);

		if(node.getRight()  !=  null)
			inOrderSubTree(node.getRight(), ar);
	}
//below methods add to the tree
	public Position<E> addRoot(E e) throws EmptyTreeException
	{
		if(size() > 0)
			throw new EmptyTreeException("theres stuff in the tree");
		root = new BTNode(e, null,null,null);
		size++;
		return root;
	}


	public Position<E> addLeft(Position<E> pos, E e) throws InvalidPositionException
	{
		BTNode<E> parent = checkPosition(pos);
		if (parent.getLeft() != null)
			throw new InvalidPositionException("pos has a left child");
		BTNode<E> child = new BTNode(e, parent, null, null);
		parent.setLeft(child);
		size++;
		return child;
	}


	public Position<E> addRight(Position<E> pos, E e) throws InvalidPositionException
	{
		BTNode<E> parent = checkPosition(pos);
		if(parent.getRight() != null)
			throw new InvalidPositionException("pos has a right child");
		BTNode<E> child = new BTNode(e, parent, null, null);
		parent.setRight(child);
		size++;
		return child;
	}
//method made for a lab
	public E replace(Position<E> pos, E e) throws InvalidPositionException
	{
		BTNode<E> node = checkPosition(pos);
		E temp = node.getElement();
		node.setElement(e);
		return temp;
	}
//removes node from tree
	public E remove(Position<E> pos) throws InvalidPositionException
	{
		BTNode<E> node = checkPosition(pos);
		BTNode<E> left = node.getLeft();
		BTNode<E> right = node.getRight();

		if (left != null && right != null)
			throw new InvalidPositionException("p has two children and cant be removed.");
		BTNode<E> child;

		if(left != null)
			child = left;

		else if(right != null)
			child = right;
		else
			child = null;

		//checck if node to be remove is root
		if(node == root)
		{
			if(child != null)
				child.setParent(null);
			root = child;
		}
		else
		{
			BTNode<E> parent = node.getParent();
			if(node == parent.getLeft())
				parent.setLeft(child);
			else
				parent.setRight(child);

			if(child != null)
				child.setParent(parent);
		}
		size--;
		return node.getElement();
	}
//attaches two subtrees at a given position
	public void attach(Position<E> pos, LinkedBinaryTree<E> t1, LinkedBinaryTree<E> t2) throws InvalidPositionException
	{
		BTNode<E> node = checkPosition(pos);
		if (isInternal(pos))
			throw new InvalidPositionException("pos has to be a leaf");

		size += t1.size() + t2.size();

		if (!t1.isEmpty())
		{
			t1.root.setParent(node);
			node.setLeft(t1.root);
			t1.root = null;
			t1.size = 0;
		}

		if (!t2.isEmpty())
		{
			t2.root.setParent(node);
			node.setRight(t2.root);
			t2.root = null;
			t2.size = 0;
		}
	}
}