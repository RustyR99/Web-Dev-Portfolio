import java.lang.*;

public interface Tree<E>
{
	public int size();
	public boolean isEmpty();

	public Iterable<E> iterator()
		throws InvalidPositionException, EmptyTreeException, BoundaryViolationException;

	public Iterable<Position<E>> positions()
		throws InvalidPositionException, EmptyTreeException, BoundaryViolationException;

	public Position<E> root()
		throws EmptyTreeException;

	public Position<E> parent(Position<E> p)
		throws InvalidPositionException;

	public Iterable<Position<E>> children(Position<E> p)
		throws InvalidPositionException, BoundaryViolationException;

	public boolean isInternal(Position<E> p)
		throws InvalidPositionException;

	public boolean isExternal(Position<E> p)
		throws InvalidPositionException;

	public boolean isRoot(Position<E> p)
		throws InvalidPositionException;

	public E replace(Position<E> p, E e)
		throws InvalidPositionException;
}