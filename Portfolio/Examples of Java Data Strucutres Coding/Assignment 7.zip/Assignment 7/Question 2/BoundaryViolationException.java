public class BoundaryViolationException extends Exception
{
	public BoundaryViolationException(String message)
	{
		super(message);
	}
}