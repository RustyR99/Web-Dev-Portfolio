import java.util.*;

public class BinarySearchDemo
{
    public static void main(String[] args)
    {
        BinarySearchTree<Integer,Integer> tree = new BinarySearchTree<Integer,Integer>();
		//generate random nums for tree
        Random rand = new Random();
		int num = 20;

       System.out.println("\nThe random integers are  \n");
		//try to add the elements and catach exceptions
        try
        {
            for (int i = 0; i < num; i++)
            {
                int x = rand.nextInt(1000);
                tree.insert(x, x);
                System.out.println(x);
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }


        System.out.println();
        System.out.println("\nThe sorted integers are  \n");
			//print out the tree using the inOrder from the rextbook
        try
        {
            System.out.println(tree.toString());
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        System.out.println("\n");




    }
}