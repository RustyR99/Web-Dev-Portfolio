public class BTNode<E> implements Position<E>
{
	E element;
	BTNode<E> left;
	BTNode<E> right;
	BTNode<E> parent;

	//4-arg constructor
	public BTNode(E e, BTNode<E> parent, BTNode<E> left, BTNode<E> right)
	{
		element = e;
		this.parent = parent;
		this.left = left;
		this.right = right;
	}

	public E getElement()
	{
		return element;
	}

	public BTNode<E> getParent()
	{
		return parent;
	}

	public BTNode<E> getLeft()
	{
		return left;
	}

	public BTNode<E> getRight()
	{
		return right;
	}

	public void setElement(E e)
	{
		element = e;
	}		

	public void setParent(BTNode p)
	{
		parent = p;
	}

	public void setLeft(BTNode l)
	{
		left = l;
	}

	public void setRight(BTNode r)
	{
		right = r;
	}
}