public class EmptyTreeException extends Exception
{
	public EmptyTreeException(String message)
	{
		super(message);
	}
}