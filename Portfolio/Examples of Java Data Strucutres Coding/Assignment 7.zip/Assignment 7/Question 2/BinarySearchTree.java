import java.util.*;

public class BinarySearchTree<K,V> extends LinkedBinaryTree<BTEntry<K,V>>
{
	protected Comparator<K> comp;

	public BinarySearchTree()
	{
		super();
		comp = new DefaultComparator<K>();
	}

	public Position<BTEntry<K,V>> find(K k, Position<BTEntry<K,V>> pos) throws InvalidPositionException
	{
		if(isExternal(pos))//if the position is external we insert there and return
		{
			return pos;
		}

		BTNode<BTEntry<K,V>> searchNode = checkPosition(pos);

		K key = searchNode.getElement().getKey();
		//these statements determine which part of the tree we go down to find our position recursively
		if(comp.compare(k,key) < 0)
		{
			if (searchNode.getLeft() == null)
				return searchNode;
			return find(k, searchNode.getLeft());
		}
		else if(comp.compare(k,key) > 0)
		{
			if (searchNode.getRight() == null)
				return searchNode;

			return find(k, searchNode.getRight());
		}
		else
		{
			return searchNode;
		}
	}

	public void insert(K k, V val) throws InvalidPositionException, EmptyTreeException
	{
		BTEntry<K,V> entry = new BTEntry<>(k,val);
		//if the tree is empty add the entry as the root
		if(isEmpty())
		{
			addRoot(entry);
		}

		else
		{
			BTNode<BTEntry<K,V>> pos = checkPosition(root());
			K key;
			//boolean to track if ive found the key or not
			boolean status = false;

			while(!status)
			{

				pos = checkPosition(find(k, pos));
				key = pos.getElement().getKey();
				int compared = comp.compare(k, key);
				//insert at left if key is smaller
				if(compared < 0)
				{
					addLeft(pos, entry);
					status = true;
				}
				else if(compared > 0)//insert at right if key is larger
				{
					addRight(pos, entry);
					status = true;
				}
				else
				{
					//if they are equal insert at the right if its null
					if (pos.getLeft() == null)
					{
						addLeft(pos, entry);
						status = true;
					}
					else//else contiinue
					{
						pos = pos.getLeft();
						status = false;
					}
				}
			}
		}
		size++;
	}
	//toString prints out the elements using my inOrder traversal method from linked tree
	public String toString()
	{
		String str = "";
		Iterable<Position<BTEntry<K,V>>> array = new ArrayList<>(size());

		try
		{
			array = inOrder();
		}
		catch(Exception e)
		{
			System.out.print(e.getMessage());
		}

		for(Position<BTEntry<K,V>> p: array)
		{
			str = str + p.getElement().getValue() + ", ";
		}
		return str;
	}
}