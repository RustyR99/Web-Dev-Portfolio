this is my pseudocode for an inOrder traversal with no recursion

inOrder()
{
	if (root = null)
		return;
		
	myStack = new Stack;
	node n = root;
	
	while(node != null || myStack.size() > 0)
	{
		while(node != null)
		{
			myStack.push(node);
			node = node.left();
		}
		node = myStack.pop();
		System.out.println(node data)
		node = node.right();
	}
}
	